import java.util.*;
import java.lang.*;

class Sales {
    static double total_sales = 0;
    static int veg_sales = 0;
    static int esp_sales = 0;
    static int cocoa_sales = 0;
    static int pizza_sales = 0;

    static public void printSales() {
        System.out.println("Sales for Today:");
        System.out.println("Total Veg Burgers Sold - " + veg_sales);
        System.out.println("Total Chicken Pizzas Sold - " + pizza_sales);
        System.out.println("Total Espressos Sold - " + esp_sales);
        System.out.println("Total Hot Cocoas Sold - " + cocoa_sales);
        System.out.println("Total Sales: $" + total_sales);
    }
}
