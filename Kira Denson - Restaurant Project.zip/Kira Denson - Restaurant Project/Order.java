import java.util.*;
import java.lang.*;

class Order {
		Integer order_total = 0;

		public Boolean Total(Integer item) {
        HashMap<Integer, Integer> prices = new HashMap<>();
        prices.put(1,10);
        prices.put(2, 15);
        prices.put(3, 5);
        prices.put(4, 3);
        prices.put(5,8);
        
        Integer price = prices.get(item);
        if (price != null) {
            Inventory.updateInventory(item);
            order_total += price; 
            Sales.total_sales += price;
            return true;
        } else {
            System.out.println("Sorry, we are out of that item! Please try again.");
            return false;
        }
    }
}
