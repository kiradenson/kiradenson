import java.util.*;
import java.lang.*;


public class Restaurant {
	static Scanner choices = new Scanner(System.in);
	static Menu menu = new Menu();
	static Inventory inventory = new Inventory();

	public static void main (String[] args) {
		Integer choice1 = null;
        
        while(choice1 == null || choice1 == 1 || choice1 == 2 || choice1 == 3 || choice1 == 4 && choice1 != 0) {
            if (choice1 == null) {
                System.out.println("--------------------------------------------------------");
				System.out.println("Welcome to the Golden Hour Restaurant Management System!");
				System.out.println("--------------------------------------------------------");
            }
            else if (choice1 == 1) {
                menu.orderLoop();
            }
            else if (choice1 == 2) {
                inventory.printReport();
            }
            else if (choice1 == 3) {
                Sales.printSales();
            }
            else {
            	System.out.println("Thank You For Using Golden Hour Management Services!");
            	System.exit(0);
            }
            choice1 = Actions();
        }
    }

	//File file = new File("/Users/kiradenson/Desktop/USF/CS112/MyWork/Project01/Inventory.txt");

    public static Integer Actions() {
		System.out.println("Press a number to access the item: ");
		System.out.println("Menu - Press 1");
		System.out.println("Check Inventory - Press 2");
		System.out.println("Generate Sales Report - Press 3");
		System.out.println("Log Out - Press 4");
        if (choices.hasNextInt()) {
            return choices.nextInt(); 
        } else {
            return 0;
        }
    }
}
