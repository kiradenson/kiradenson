import java.util.*;
import java.lang.*;

class Inventory {
	static int bun = 1000;
	static int dough = 1500;
    static int onion = 1000; 
    static int tomato = 1000;
    static int lettuce = 1800;
    static int ketchup = 1000; 
    static int mayo = 1500;
    static int coffee = 1500; 
    static int cocoa = 1500; 
    static int creamer = 1500;
    static int sugar = 1500; 
    static int salt = 1500; 
    static int pepper = 1500; 
    static int cheese = 2000; 
    static int olives = 1500; 
    static int bellPepper = 1000;
    static int milk = 2000; 
    static int chicken = 1500;

    public void printReport() {
        System.out.println("Items left in inventory:");
        System.out.println("Bun - " + bun + " slices"); 
        System.out.println("Wheat Dough - " + dough + " slices");
        System.out.println("Onions - " + onion + " slices"); 
        System.out.println("Tomato - " + tomato + " slices");
        System.out.println("Lettuce - " + lettuce + " leaves"); 
        System.out.println("Ketchup - " + ketchup + " packets");
        System.out.println("Mayonnaise - " + mayo + " packets"); 
        System.out.println("Coffee Powder - " + coffee + " packets");
        System.out.println("Cocoa Powder - " + cocoa + " packets"); 
        System.out.println("Creamer - " + creamer + " bottles");
        System.out.println("Sugar - " + sugar + " packets"); 
        System.out.println("Salt - " + salt + " bags");
        System.out.println("Pepper - " + pepper + " packets"); 
        System.out.println("Cheese - " + cheese + " slices");
        System.out.println("Olives - " + olives); 
        System.out.println("Bell Peppers - " + bellPepper);
        System.out.println("Milk - " + milk + " cartons"); 
        System.out.println("Chicken - " + chicken);
        System.out.println(" ");
    }

    static public void updateInventory(Integer item) {
        if (item == 1) {
            Inventory.vegburg();
            Sales.veg_sales += 1;
        }
        else if(item == 2) {
            Inventory.pizza();
            Sales.pizza_sales += 1;
        }
        else if (item ==3) {
            Inventory.espresso();
            Sales.esp_sales += 1;
        }
        else if (item == 4) {
            Inventory.hotCocoa();
            Sales.cocoa_sales += 1;
        }
    }

	public static void vegburg() {
        bun -= 1; 
        tomato -=2; 
        onion -=2; 
        lettuce -= 0.7;
        cheese -=2; 
        ketchup -=1; 
        mayo -= 1; 
        salt -= 1; 
        pepper -=1;
    }
    public static void pizza() { 
        dough -=1; 
        chicken -= 7; 
        ketchup -= 1;
        bellPepper -= 2; 
        onion -= 2; 
        tomato -= 2; 
        olives -= 1;
        salt -= 1; 
        pepper -=1; 
        cheese -= 3;
    }
    public static void espresso() {
        coffee -=1; 
        milk -=5; 
        sugar -=1; 
        creamer -=1;
    }
    public static void hotCocoa() {
        cocoa -=1; 
        milk -=5; 
        sugar -=1; 
        creamer -=1;
    }
}
