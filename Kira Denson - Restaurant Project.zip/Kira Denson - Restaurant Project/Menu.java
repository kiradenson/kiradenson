import java.util.*;
import java.lang.*;

class Menu {
	Scanner scan = new Scanner(System.in);
	Order order = new Order();     //creates new order
    double total = 0;

    public Integer menu() {
    	System.out.println("Menu: ");
		System.out.println("1. Veg Burger - $10");
		System.out.println("2. Chicken Pizza - $15");
		System.out.println("3. Espresso - $5");
		System.out.println("4. Hot Cocoa - $3");
		System.out.println("What would you like to order? Press 1, 2, 3 or 4: ");

		try {
            Integer foodOrdered = scan.nextInt();
            return foodOrdered;
        } catch (InputMismatchException err) {
            return 0;
        }
    }

    public String orderLoop() {
        String repeat = "yes";
        while (repeat.equalsIgnoreCase("yes")) {
            Integer orderNumber = menu();
            Boolean itemExists = order.Total(orderNumber);
            if (itemExists) {
                System.out.println("Would you like to order anything else? Yes or No: ");
                repeat = scan.next();
            } else {
                repeat = scan.next();
            }
        }
        System.out.println("Your order total is $" + order.order_total);
        return repeat;
	}
}
